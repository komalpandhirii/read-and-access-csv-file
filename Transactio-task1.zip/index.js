const express = require('express');
const config = require('./connection/connection');
const mysql = require('mysql')
// // const readerRouter = require('./router/read.router');
const path = require('path');
const fs = require('fs')
const moment = require('moment');
const validator = require('validator');
const knex = require('./connection/connection');

const app = express();

// // app.use('/read',readerRouter);

const data = fs.readFileSync('/home/komal/Documents/csvAccessFile - Task/flat_file/pending_file/TXN_FILE_150320221113.txt','utf8')
 
const allData = data.toString().split('\n');

const getData = [];
let arr = [];
let err_count = 0;
let success_count = 0;
let total_count = 0;
let mem_id ;
let flat_id;

const keys = allData[0].split('|')

for(let i = 1; i < allData.length ; i++){
    let singleData = allData[i].split('|')
    let jsonObj = {}

    for(let j= 0 ; j < singleData.length ; j++){
        jsonObj[keys[j]] = singleData[j]
    }

    getData.push(jsonObj);
}

let filename = path.basename('home/komal/Documents/csvAccessFile - Task/flat_file/pending_file/TXN_FILE_150320221113.txt')
let files = filename.split("_")
const fileValidation = files[2].split('.')

const main_function = async () => {



if(moment(fileValidation[0],"DDMMYYYYHHmm",true).isValid()){

if(keys.length == 4){

   if(keys[0] === 'TransactionDate' && keys[1] === 'CardNo' && keys[2] === 'Amount' && keys[3] === 'UniqueTransactionId'){

    for(let i = 0 ; i < getData.length; i++){
        let ERR = '';

        let currentDate = moment(new Date()).format('YYYY-MM-DD');

        if(getData[i].TransactionDate > currentDate){
            ERR += 'Date is greater than Current Date'
        }

        if(getData[i].CardNo.length != 12){
            ERR += 'Card Number Not Valid'
        }

        if(!validator.isNumeric(getData[i].Amount)){
            ERR += 'Amount is in not Numeric'
        }

        if(getData[i].CardNo === ''){
            ERR +=  'Card Number is not Mention'
        }

        if(!(moment(getData[i].TransactionDate ,'YYYYMMDD HH:mm:SS').isValid())){
            ERR += 'Transaction Date is not Valid'
        }

        let uniqueId = getData[i].UniqueTransactionId;

        if(arr.includes(uniqueId)){
            ERR += 'Transaction ID already exist'
        }
        else{
            arr.push(uniqueId);
        } 
        if(ERR != ''){
            err_count = err_count + 1
            Status = ERR
            failed = 'FAILED'
            getData[i].Status = failed
            getData[i].error = Status

        }
        else{
            success_count += 1
            success = 'SUCCESS'
            getData[i].Status = success


            let flatFile = {
                flatFileName : filename
            }

            console.log(flatFile);

          let transacDetail;

          knex('user')
          .select('memberId')
          .where('card_no' , getData[i].CardNo)
          .first().then((result) => knex('flat_file')
          .select('flatFileId')
          .orderBy("flatFileId" , "desc")
          .first()
          .then((result1) => 
          
           transacDetail = {
                unique_transaction_id : getData[i].UniqueTransactionId,
                memberId : result.memberId,
                flatFileId : result1.flatFileId,
                transaction_date : getData[i].TransactionDate,
                card_no : getData[i].CardNo,
                amount : getData[i].Amount,
          }
          ).then(() => knex('transactionTable').insert(transacDetail).then((result3) => console.log(result3)))
          )        
          
        }

        // ---------------- Cannot able to insert data in Flat_file_data table

        let flatFileData;

        // knex('transactionTable')
        // .select('flatFileId')
        // .orderBy('flatFileId' , 'desc')
        // .first()
        // .then((result4) =>
        // flatFileData = {
        //     flatFileDataId : 1,
        //     transactionDate : getData[i].TransactionDate,
        //     card_no : getData[i].CardNo,
        //     amount : getData[i].Amount,
        //     status : getData[i].Status,
        //     error : getData[i].error
        // }
        // )
        // .then(() => knex('flat_file_data').insert(flatFileData).then((result5) => console.log(result5)))
    }

    total_count = success_count + err_count

    let flat_file = {
        file_name: filename,
        total_count: total_count,
        success_count: success_count,
        failure_count: err_count
    }

    console.log(flat_file);

     knex('flat_file').insert(flat_file)
    .then ((result)=> console.log(result))

    // success_count = success_count + 1

    let total_success = success_count
    let total_err = err_count

    console.log(total_success); // Total success data in the File
    console.log(total_err); // Total error data in the File
    console.log(total_success + total_err);  // Total Data in the file

console.log(getData);

}
}
}
}

main_function();

const port = 3400

app.listen(port,() =>{
    console.log('Listening to PORT '+port );
})