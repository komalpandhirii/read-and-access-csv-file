
const mysql = require('mysql')
const config = {
    host:'localhost',
    user:'root',
    password:'Admin@123',
    database:'flatFiles'

}
module.exports = config;