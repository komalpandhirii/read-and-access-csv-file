const config = {
    host:'localhost',
    user:'root',
    password:'Admin@123',
    database:'csvFiles'

}
module.exports = config;