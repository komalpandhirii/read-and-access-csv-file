const fs = require('fs');
const path = require('path');
const moment = require('moment');
const validator = require('validator');

// const data = fs.readFileSync('/home/komal/Documents/csvAccessFile - Task/flat_file/pending_file/TXN_FILE_150320221113.txt','utf8')
 
// const allData = data.toString().split('\n');
// // console.log(allData);

// const getData = []

// const heading = allData[0].split('|')

// for(let i = 1; i < allData.length ; i++){
//     let singleData = allData[i].split('|')
//     let jsonObj = {}

//     for(let j= 0 ; j < singleData.length ; j++){
//         jsonObj[heading[j]] = singleData[j]
//     }

//     getData.push(jsonObj);
// }

// let arr = [];

module.exports = class readController {

constructor () {}

async moveFile (req,res){

    let filename = path.basename('home/komal/Documents/csvAccessFile - Task/flat_file/pending_file/TXN_FILE_150320221113.txt')
    let files = filename.split("_")
    const fileValidation = files[2].split('.')

    let a =  moment(fileValidation[0],"DDMMYYYYHHmm",true).isValid()

    for(let i = 0 ; i < getData.length; i++){

        // let condition1 = getData[i].CardNo.length == 12
        if(getData[i].CardNo.length == 12){
            console.log('Card Number is 12');
        }
        else{
            console.log('Card Number is not 12');
        }

        // let condition2 = validator.isNumeric(getData[i].Amount)
        if(validator.isNumeric(getData[i].Amount)){
            console.log('Amount is in Numeric Data')
        }

        // let condition3 =   moment(getData[i].TransactionDate,'YYYYMMDD HH:mm:SS').isValid()
        if(moment(getData[i].TransactionDate , 'YYYYMMDD HH:mm:SS').isValid()){
            console.log('Date formate is Corect');
        }

        let currentDate = moment(new Date()).format('YYYY-MM-DD');
        // console.log(currentDate);

        let condition4 = getData[i].TransactionDate < currentDate;
        // console.log(condition4);

        let items = getData[i].UniqueTransactionId;

        // arr.push(items);

        if(arr.includes(items)){
            console.log('log of condition5 if');
            console.log(i + 2);
        }
        else{

            console.log('log of condition5 else');
            arr.push(items);
        }

        // if(condition1 && condition2 && condition3 && condition4 && condition5()){
        //     console.log(true);
        // }
        // else{
        //     console.log(false);
        // }
    }

}

}