const express = require('express');
const config = require('./connection/connection');
const readerRouter = require('./router/read.router');
const path = require('path');
const fs = require('fs')
const moment = require('moment');
const validator = require('validator');

const app = express();

app.use('/read',readerRouter);

const data = fs.readFileSync('/home/komal/Documents/csvAccessFile - Task/flat_file/pending_file/TXN_FILE_150320221113.txt','utf8')
 
const allData = data.toString().split('\n');

const getData = [];
let arr = [];
let err_count = 0;
let success_count = 0;
let count = 0;


const keys = allData[0].split('|')

for(let i = 1; i < allData.length ; i++){
    let singleData = allData[i].split('|')
    let jsonObj = {}

    for(let j= 0 ; j < singleData.length ; j++){
        jsonObj[keys[j]] = singleData[j]
    }

    getData.push(jsonObj);
}


let filename = path.basename('home/komal/Documents/csvAccessFile - Task/flat_file/pending_file/TXN_FILE_150320221113.txt')
let files = filename.split("_")
const fileValidation = files[2].split('.')

// console.log(fileValidation[0]);

if(moment(fileValidation[0],"DDMMYYYYHHmm",true).isValid()){

if(keys.length == 4){

   if(keys[0] === 'TransactionDate' && keys[1] === 'CardNo' && keys[2] === 'Amount' && keys[3] === 'UniqueTransactionId'){

    for(let i = 0 ; i < getData.length; i++){
        let ERR = '';

        let currentDate = moment(new Date()).format('YYYY-MM-DD');

        if(getData[i].TransactionDate > currentDate){
            ERR += 'Date is greater than Current Date'
        }

        if(getData[i].CardNo.length != 12){
            ERR += 'Card Number Not Valid'
        }

        if(!validator.isNumeric(getData[i].Amount)){
            ERR += 'Amount is in not Numeric'
        }

        if(getData[i].CardNo === ''){
            ERR +=  'Card Number is not Mention'
        }

        if(!(moment(getData[i].TransactionDate ,'YYYYMMDD HH:mm:SS').isValid())){
            ERR += 'Transaction Date is not Valid'
        }

        let items = getData[i].UniqueTransactionId;

        if(arr.includes(items)){
            ERR += 'Transaction ID already exist'
        }
        else{
            arr.push(items);

        } if(ERR != ''){
            err_count = err_count + 1
            Status = ERR
            failed = 'FAILED'
            getData[i].Status = failed
            getData[i].error = Status
        }
        else{
            success_count += 1
            success = 'SUCCESS'
            getData[i].Status = success
        }
    }

    // success_count = success_count + 1

    let total_success = success_count
    let total_err = err_count

    console.log(total_success);
    console.log(total_err);
}
}
}
// console.log(getData);

const port = 9000

app.listen(port,() =>{
    console.log('Listening to PORT '+port );
})









