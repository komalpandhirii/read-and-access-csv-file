create database flatFiles;

use flatFiles;

create table 