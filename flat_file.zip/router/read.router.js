const express = require('express');

const readController = require('../controller/read.controller');

const controller = new readController()

const router = express.Router();

// router.get('/readCsv',controller.readCsv);

router.get('/moveFile',controller.moveFile)

module.exports = router;


